package DB__package;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

import BUI_Package.FrontDeskStaff;
import BUI_Package.FrontDesk_login;
import BUI_Package.Member;
import BUI_Package.Member_login;
import BUI_Package.Trainer;
import BUI_Package.Trainer_login;

public class DB_CLASS1 {

	private static DB_CLASS1 instance = null;

	
	 private DB_CLASS1() {
	  
	  }
	 

	public static synchronized DB_CLASS1 getinstance() {
		if (instance == null) {
			instance = new DB_CLASS1();
		}
		return instance;
	}

	private JFrame frame;
	private JTable table;
	protected String id1;

	/**
	 * Launch the application.
	 */
	private String getCurrentDate() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		return dateFormat.format(new Date());
	}

	public void viewmessage() {
		System.out.println("akdsdyasydauda");
	}

	public void RegisterMemberhip(String id, String name, String contact, String type) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Check if the member with the same ID already exists
			String selectSql = "SELECT * FROM Membership WHERE id = ?";

			try (PreparedStatement selectPstmt = con.prepareStatement(selectSql)) {
				// Set the value for the parameter
				selectPstmt.setString(1, id);

				// Execute the SELECT query
				ResultSet resultSet = selectPstmt.executeQuery();

				// Check if the ID already exists
				if (resultSet.next()) {
					// Member with the same ID already exists, handle accordingly (e.g., show an
					// error message)
					JOptionPane.showMessageDialog(null, "Member with ID " + id + " already exists. Insert failed.",
							"Error", JOptionPane.ERROR_MESSAGE);
					System.out.println("Member with ID " + id + " already exists. Insert failed.");
				} else {

					// ID not found, proceed with the INSERT operation
					String insertSql = "INSERT INTO Membership (id, name, contact, type) VALUES (?, ?, ?, ?)";

					try (PreparedStatement insertPstmt = con.prepareStatement(insertSql)) {
						// Set the values for the parameters
						insertPstmt.setString(1, id);
						insertPstmt.setString(2, name);
						insertPstmt.setString(3, contact);
						insertPstmt.setString(4, type);

						// Execute the INSERT query
						int rowsInserted = insertPstmt.executeUpdate();

						System.out.println("Rows inserted: " + rowsInserted);
					}
				}
			}
		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	/////////////////// Update Membership/////////////////////////////////////

	public void UpdateMemberhip(String id, String name, String contact, String type) {
		System.out.println("Updating record");
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Use PreparedStatement to safely handle parameters and prevent SQL injection
			String selectSql = "SELECT * FROM Membership WHERE id = ?";

			try (PreparedStatement selectPstmt = con.prepareStatement(selectSql)) {
				// Set the value for the parameter
				selectPstmt.setString(1, id);

				// Execute the SELECT query
				ResultSet resultSet = selectPstmt.executeQuery();

				// Check if the ID exists
				if (resultSet.next()) {
					// ID found, proceed with the UPDATE operation
					String updateSql = "UPDATE Membership SET name = ?, contact = ?, type = ? WHERE id = ?";

					try (PreparedStatement updatePstmt = con.prepareStatement(updateSql)) {
						// Set the values for the parameters
						updatePstmt.setString(1, name);
						updatePstmt.setString(2, contact);
						updatePstmt.setString(3, type);
						updatePstmt.setString(4, id);

						// Execute the UPDATE query
						int rowsUpdated = updatePstmt.executeUpdate();

						System.out.println("Rows updated: " + rowsUpdated);
					}
				} else {
					// ID not found, handle accordingly (e.g., show an error message)
					JOptionPane.showMessageDialog(null, "ID not found. Update failed.", "Error",
							JOptionPane.ERROR_MESSAGE);
					System.out.println("ID not found. Update failed.");

				}
			}
		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	//////////////////////////////// VIEW MEMBERS//////////////////////////

	public void deletemembers(String id) {
		System.out.println("Deleting record");

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Use PreparedStatement to safely handle parameters and prevent SQL injection
			String selectSql = "SELECT * FROM Membership WHERE id = ?";

			try (PreparedStatement selectPstmt = con.prepareStatement(selectSql)) {
				// Set the value for the parameter
				selectPstmt.setString(1, id);

				// Execute the SELECT query
				ResultSet resultSet = selectPstmt.executeQuery();

				// Check if the ID exists
				if (resultSet.next()) {
					// ID found, proceed with the DELETE operation

					// Delete from Membership table
					String deleteMembershipSql = "DELETE FROM Membership WHERE id = ?";
					try (PreparedStatement deleteMembershipPstmt = con.prepareStatement(deleteMembershipSql)) {
						// Set the value for the parameter
						deleteMembershipPstmt.setString(1, id);

						// Execute the DELETE query for Membership table
						int rowsDeletedMembership = deleteMembershipPstmt.executeUpdate();

						System.out.println("Rows deleted from Membership: " + rowsDeletedMembership);
					}

					// Delete from Classes table
					String deleteClassesSql = "DELETE FROM Classes WHERE memberid = ?";
					try (PreparedStatement deleteClassesPstmt = con.prepareStatement(deleteClassesSql)) {
						// Set the value for the parameter
						deleteClassesPstmt.setString(1, id);

						// Execute the DELETE query for Classes table
						int rowsDeletedClasses = deleteClassesPstmt.executeUpdate();

						System.out.println("Rows deleted from Classes: " + rowsDeletedClasses);
					}

					// Delete from Payment table
					String deletePaymentSql = "DELETE FROM Payment WHERE id = ?";
					try (PreparedStatement deletePaymentPstmt = con.prepareStatement(deletePaymentSql)) {
						// Set the value for the parameter
						deletePaymentPstmt.setString(1, id);

						// Execute the DELETE query for Payment table
						int rowsDeletedPayment = deletePaymentPstmt.executeUpdate();

						System.out.println("Rows deleted from Payment: " + rowsDeletedPayment);
					}

					// Delete from Alerts table
					String deleteAlertsSql = "DELETE FROM Alerts WHERE id = ?";
					try (PreparedStatement deleteAlertsPstmt = con.prepareStatement(deleteAlertsSql)) {
						// Set the value for the parameter
						deleteAlertsPstmt.setString(1, id);

						// Execute the DELETE query for Alerts table
						int rowsDeletedAlerts = deleteAlertsPstmt.executeUpdate();

						System.out.println("Rows deleted from Alerts: " + rowsDeletedAlerts);
					}

					// Delete from Attendance table
					String deleteAttendanceSql = "DELETE FROM Attendance WHERE id = ?";
					try (PreparedStatement deleteAttendancePstmt = con.prepareStatement(deleteAttendanceSql)) {
						// Set the value for the parameter
						deleteAttendancePstmt.setString(1, id);

						// Execute the DELETE query for Attendance table
						int rowsDeletedAttendance = deleteAttendancePstmt.executeUpdate();

						System.out.println("Rows deleted from Attendance: " + rowsDeletedAttendance);
					}

				} else {
					// ID not found, handle accordingly (e.g., show an error message)
					JOptionPane.showMessageDialog(null, "ID not found. Deletion failed.", "Error",
							JOptionPane.ERROR_MESSAGE);
					System.out.println("ID not found. Deletion failed.");
				}
			}
		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	/////////////////////////// INVENTORY ADD ITEM //////////////////////////////

	public void additem(String id, String name, String status) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Check if the member with the same ID already exists
			String selectSql = "SELECT * FROM Inventory WHERE id = ?";

			try (PreparedStatement selectPstmt = con.prepareStatement(selectSql)) {
				// Set the value for the parameter
				selectPstmt.setString(1, id);

				// Execute the SELECT query
				ResultSet resultSet = selectPstmt.executeQuery();

				// Check if the ID already exists
				if (resultSet.next()) {
					// Member with the same ID already exists, handle accordingly (e.g., show an
					// error message)
					JOptionPane.showMessageDialog(null, "Item with ID " + id + " already exists. Insert failed.",
							"Error", JOptionPane.ERROR_MESSAGE);
					System.out.println("Item with ID " + id + " already exists. Insert failed.");
				} else {
					// ID not found, proceed with the INSERT operation
					String insertSql = "INSERT INTO Inventory (id, name, status) VALUES (?, ?, ?)";

					try (PreparedStatement insertPstmt = con.prepareStatement(insertSql)) {
						// Set the values for the parameters
						insertPstmt.setString(1, id);
						insertPstmt.setString(2, name);
						insertPstmt.setString(3, status);

						// Execute the INSERT query
						int rowsInserted = insertPstmt.executeUpdate();

						System.out.println("Rows inserted: " + rowsInserted);
					}
				}
			}
		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	/////////////////////////////// Update Inventory ///////////////////////////

	public void changestatus(String id, String status) {
		System.out.println("Updating record");
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Use PreparedStatement to safely handle parameters and prevent SQL injection
			String selectSql = "SELECT * FROM Inventory WHERE id = ?";

			try (PreparedStatement selectPstmt = con.prepareStatement(selectSql)) {
				// Set the value for the parameter
				selectPstmt.setString(1, id);

				// Execute the SELECT query
				ResultSet resultSet = selectPstmt.executeQuery();

				// Check if the ID exists
				if (resultSet.next()) {
					// ID found, proceed with the UPDATE operation
					String updateSql = "UPDATE Inventory SET status = ? WHERE id = ?";

					try (PreparedStatement updatePstmt = con.prepareStatement(updateSql)) {
						// Set the values for the parameters

						updatePstmt.setString(1, status);

						updatePstmt.setString(2, id);

						// Execute the UPDATE query
						int rowsUpdated = updatePstmt.executeUpdate();

						System.out.println("Rows updated: " + rowsUpdated);
					}
				} else {
					// ID not found, handle accordingly (e.g., show an error message)
					JOptionPane.showMessageDialog(null, "ID not found. Update failed.", "Error",
							JOptionPane.ERROR_MESSAGE);
					System.out.println("ID not found. Update failed.");

				}
			}
		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	///////////////////////////////// DELETE INVENTORY ITEM
	///////////////////////////////// //////////////////////////////////

	public void deleteitem(String id) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Use PreparedStatement to safely handle parameters and prevent SQL injection
			String selectSql = "SELECT * FROM Inventory WHERE id = ?";

			try (PreparedStatement selectPstmt = con.prepareStatement(selectSql)) {
				// Set the value for the parameter
				selectPstmt.setString(1, id);

				// Execute the SELECT query
				ResultSet resultSet = selectPstmt.executeQuery();

				// Check if the ID exists
				if (resultSet.next()) {
					// ID found, proceed with the DELETE operation
					String deleteSql = "DELETE FROM Inventory WHERE id = ?";

					try (PreparedStatement deletePstmt = con.prepareStatement(deleteSql)) {
						// Set the value for the parameter
						deletePstmt.setString(1, id);

						// Execute the DELETE query
						int rowsDeleted = deletePstmt.executeUpdate();

						System.out.println("Rows deleted: " + rowsDeleted);
					}
				} else {
					// ID not found, handle accordingly (e.g., show an error message)
					JOptionPane.showMessageDialog(null, "ID not found. Deletion failed.", "Error",
							JOptionPane.ERROR_MESSAGE);
					System.out.println("ID not found. Deletion failed.");

				}
			}
		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	///////////////////////////////////// Payment
	///////////////////////////////////// ///////////////////////////////////////

	public void payment(String id, String amount, String date) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Check if the member exists in the Membership table
			String memberCheckSql = "SELECT * FROM Membership WHERE id = ?";

			try (PreparedStatement memberCheckPstmt = con.prepareStatement(memberCheckSql)) {
				// Set the value for the parameter
				memberCheckPstmt.setString(1, id);

				// Execute the SELECT query
				ResultSet memberCheckResultSet = memberCheckPstmt.executeQuery();

				// Check if the member exists
				if (!memberCheckResultSet.next()) {
					// Member doesn't exist, handle accordingly (e.g., show an error message)
					JOptionPane.showMessageDialog(null, "Member with ID " + id + " doesn't exist. Insert failed.",
							"Error", JOptionPane.ERROR_MESSAGE);
					System.out.println("Member with ID " + id + " doesn't exist. Insert failed.");
					return; // Exit the method, as there's no point in proceeding further
				}
			}

			// Check if the ID already exists in the payment table
			String paymentCheckSql = "SELECT * FROM payment WHERE id = ?";

			try (PreparedStatement paymentCheckPstmt = con.prepareStatement(paymentCheckSql)) {
				// Set the value for the parameter
				paymentCheckPstmt.setString(1, id);

				// Execute the SELECT query
				ResultSet paymentCheckResultSet = paymentCheckPstmt.executeQuery();

				// Check if the ID already exists in the payment table
				if (paymentCheckResultSet.next()) {
					// ID already exists in the payment table, handle accordingly (e.g., show an
					// error message)
					JOptionPane.showMessageDialog(null,
							"Payment record with ID " + id + " already exists. Insert failed.", "Error",
							JOptionPane.ERROR_MESSAGE);
					System.out.println("Payment record with ID " + id + " already exists. Insert failed.");
				} else {
					// ID not found in the payment table, proceed with the INSERT operation
					String insertSql = "INSERT INTO payment (id, amount, Date) VALUES (?, ?, ?)";

					try (PreparedStatement insertPstmt = con.prepareStatement(insertSql)) {
						// Set the values for the parameters
						insertPstmt.setString(1, id);
						insertPstmt.setString(2, amount);
						insertPstmt.setString(3, date);

						// Execute the INSERT query
						int rowsInserted = insertPstmt.executeUpdate();

						System.out.println("Rows inserted: " + rowsInserted);
					}
				}
			}
		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	//////////////////////////////// Payment Update ////////////////////////////////

	public void update(String id, String amount, String date) {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Check if the member exists in the Membership table
			String memberCheckSql = "SELECT * FROM Membership WHERE id = ?";

			try (PreparedStatement memberCheckPstmt = con.prepareStatement(memberCheckSql)) {
				// Set the value for the parameter
				memberCheckPstmt.setString(1, id);

				// Execute the SELECT query
				ResultSet memberCheckResultSet = memberCheckPstmt.executeQuery();

				// Check if the member exists
				if (!memberCheckResultSet.next()) {
					// Member doesn't exist, handle accordingly (e.g., show an error message)
					JOptionPane.showMessageDialog(null, "Member with ID " + id + " doesn't exist. Insert failed.",
							"Error", JOptionPane.ERROR_MESSAGE);
					System.out.println("Member with ID " + id + " doesn't exist. Insert failed.");
					return; // Exit the method, as there's no point in proceeding further
				}
			}

			// Check if the ID already exists in the payment table
			String paymentCheckSql = "SELECT * FROM payment WHERE id = ?";

			try (PreparedStatement paymentCheckPstmt = con.prepareStatement(paymentCheckSql)) {
				// Set the value for the parameter
				paymentCheckPstmt.setString(1, id);

				// Execute the SELECT query
				ResultSet paymentCheckResultSet = paymentCheckPstmt.executeQuery();

				// Check if the ID already exists in the payment table
				if (paymentCheckResultSet.next()) {

					// ID found, proceed with the UPDATE operation
					String updateSql = "UPDATE payment SET amount = ?, Date =? WHERE id = ?";

					try (PreparedStatement updatePstmt = con.prepareStatement(updateSql)) {
						// Set the values for the parameters
						updatePstmt.setString(1, amount);
						updatePstmt.setString(2, date);
						updatePstmt.setString(3, id);

						// Execute the UPDATE query
						int rowsUpdated = updatePstmt.executeUpdate();

						System.out.println("Rows updated: " + rowsUpdated);

					}

				} else {
					// ID already exists in the payment table, handle accordingly (e.g., show an
					// error message)
					JOptionPane.showMessageDialog(null,
							"Payment record with ID " + id + " doesn't exist. Insert failed.", "Error",
							JOptionPane.ERROR_MESSAGE);
					System.out.println("Payment record with ID " + id + " doesn't exist. Insert failed.");
				}
			}
		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	////////////////////////////////////////// Add Class
	////////////////////////////////////////// ///////////////////////////////////

	public void addclass(String classid, String name, String capacity, String trainerid) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Check if the trainer exists in the Trainer table
			String trainerCheckSql = "SELECT * FROM Trainer WHERE id = ?";

			try (PreparedStatement trainerCheckPstmt = con.prepareStatement(trainerCheckSql)) {
				// Set the value for the parameter
				trainerCheckPstmt.setString(1, trainerid);

				// Execute the SELECT query
				ResultSet trainerCheckResultSet = trainerCheckPstmt.executeQuery();

				// Check if the trainer exists
				if (!trainerCheckResultSet.next()) {
					// Trainer doesn't exist, handle accordingly (e.g., show an error message)
					JOptionPane.showMessageDialog(null,
							"Trainer with ID " + trainerid + " doesn't exist. Insert failed.", "Error",
							JOptionPane.ERROR_MESSAGE);
					System.out.println("Trainer with ID " + trainerid + " doesn't exist. Insert failed.");
					return; // Exit the method, as there's no point in proceeding further
				}
			}

			// Check if the trainer with the same ID is already assigned to a class
			String classCheckSql = "SELECT * FROM Fitness_Class WHERE TrainerID = ? OR Classid = ?";

			try (PreparedStatement classCheckPstmt = con.prepareStatement(classCheckSql)) {
				// Set the values for the parameters
				classCheckPstmt.setString(1, trainerid);
				classCheckPstmt.setString(2, classid);

				// Execute the SELECT query
				ResultSet classCheckResultSet = classCheckPstmt.executeQuery();

				// Check if the trainer is already assigned to a class or if the class ID
				// already exists
				if (classCheckResultSet.next()) {
					// Trainer is already assigned to a class or class with the same ID exists,
					// handle accordingly (e.g., show an error message)
					JOptionPane
							.showMessageDialog(null,
									"Trainer with ID " + trainerid + " is already assigned to a class or Class with ID "
											+ classid + " already exists. Insert failed.",
									"Error", JOptionPane.ERROR_MESSAGE);
					System.out.println(
							"Trainer with ID " + trainerid + " is already assigned to a class or Class with ID "
									+ classid + " already exists. Insert failed.");
				} else {
					// Trainer is not assigned to a class and Class with the same ID doesn't exist,
					// proceed with the INSERT operation
					String insertSql = "INSERT INTO Fitness_Class (Classid, name, Capacity, TrainerID) VALUES (?, ?, ?, ?)";

					try (PreparedStatement insertPstmt = con.prepareStatement(insertSql)) {
						// Set the values for the parameters
						insertPstmt.setString(1, classid);
						insertPstmt.setString(2, name);
						insertPstmt.setString(3, capacity);
						insertPstmt.setString(4, trainerid);

						// Execute the INSERT query
						int rowsInserted = insertPstmt.executeUpdate();

						System.out.println("Rows inserted: " + rowsInserted);
					}
				}
			}
		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	///////////////////////////////////// Update Class
	///////////////////////////////////// ///////////////////////////////

	public void updateclass(String classid, String name, String capacity, String trainerid) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Check if the trainer exists in the Trainer table
			String trainerCheckSql = "SELECT * FROM Trainer WHERE id = ?";

			try (PreparedStatement trainerCheckPstmt = con.prepareStatement(trainerCheckSql)) {
				// Set the value for the parameter
				trainerCheckPstmt.setString(1, trainerid);

				// Execute the SELECT query
				ResultSet trainerCheckResultSet = trainerCheckPstmt.executeQuery();

				// Check if the trainer exists
				if (!trainerCheckResultSet.next()) {
					// Trainer doesn't exist, handle accordingly (e.g., show an error message)
					JOptionPane.showMessageDialog(null,
							"Trainer with ID " + trainerid + " doesn't exist. Update failed.", "Error",
							JOptionPane.ERROR_MESSAGE);
					System.out.println("Trainer with ID " + trainerid + " doesn't exist. Update failed.");
					return; // Exit the method, as there's no point in proceeding further
				}
			}

			// Check if the trainer with the same ID is already assigned to another class
			String trainerClassCheckSql = "SELECT * FROM Fitness_Class WHERE TrainerID = ? AND Classid <> ?";

			try (PreparedStatement trainerClassCheckPstmt = con.prepareStatement(trainerClassCheckSql)) {
				// Set the values for the parameters
				trainerClassCheckPstmt.setString(1, trainerid);
				trainerClassCheckPstmt.setString(2, classid);

				// Execute the SELECT query
				ResultSet trainerClassCheckResultSet = trainerClassCheckPstmt.executeQuery();

				// Check if the trainer is already assigned to another class
				if (trainerClassCheckResultSet.next()) {
					// Trainer is already assigned to another class, show an error message
					JOptionPane.showMessageDialog(null,
							"Trainer with ID " + trainerid + " is already assigned to another class. Update failed.",
							"Error", JOptionPane.ERROR_MESSAGE);
					System.out.println(
							"Trainer with ID " + trainerid + " is already assigned to another class. Update failed.");
					return; // Exit the method, as there's no point in proceeding further
				} else {
					// Trainer is already assigned to a class or class with the same ID exists,
					// proceed with the UPDATE operation
					String updateSql = "UPDATE Fitness_Class SET name = ?, Capacity = ?, TrainerID = ? WHERE Classid = ?";

					try (PreparedStatement updatePstmt = con.prepareStatement(updateSql)) {
						// Set the values for the parameters
						updatePstmt.setString(1, name);
						updatePstmt.setString(2, capacity);
						updatePstmt.setString(3, trainerid);
						updatePstmt.setString(4, classid);

						// Execute the UPDATE query
						int rowsUpdated = updatePstmt.executeUpdate();

						System.out.println("Rows updated: " + rowsUpdated);
					}
				}
			}

		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	/////////////////////////////////////// Delete Class //////////////////////////

	public void deleteclass(String id) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Use PreparedStatement to safely handle parameters and prevent SQL injection
			String selectSql = "SELECT * FROM Fitness_Class WHERE Classid = ?";

			try (PreparedStatement selectPstmt = con.prepareStatement(selectSql)) {
				// Set the value for the parameter
				selectPstmt.setString(1, id);

				// Execute the SELECT query
				ResultSet resultSet = selectPstmt.executeQuery();

				// Check if the ID exists
				if (resultSet.next()) {
					// ID found, proceed with the DELETE operation

					// Delete from Membership table
					String deleteMembershipSql = "DELETE FROM Fitness_Class WHERE Classid = ?";
					try (PreparedStatement deleteMembershipPstmt = con.prepareStatement(deleteMembershipSql)) {
						// Set the value for the parameter
						deleteMembershipPstmt.setString(1, id);

						// Execute the DELETE query for Membership table
						int rowsDeletedMembership = deleteMembershipPstmt.executeUpdate();

						System.out.println("Rows deleted from Fitness_Class: " + rowsDeletedMembership);
					}

				} else {
					// ID not found, handle accordingly (e.g., show an error message)
					JOptionPane.showMessageDialog(null, "ID not found. Deletion failed.", "Error",
							JOptionPane.ERROR_MESSAGE);
					System.out.println("ID not found. Deletion failed.");
				}
			}
		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	public void enrollmember(String mid, String cid) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Check if the member exists in the Membership table
			String memberCheckSql = "SELECT * FROM Membership WHERE id = ?";

			try (PreparedStatement memberCheckPstmt = con.prepareStatement(memberCheckSql)) {
				// Set the value for the parameter
				memberCheckPstmt.setString(1, mid);

				// Execute the SELECT query
				ResultSet memberCheckResultSet = memberCheckPstmt.executeQuery();

				// Check if the member exists
				if (!memberCheckResultSet.next()) {
					// Member doesn't exist, show an error message
					JOptionPane.showMessageDialog(null, "Member with ID " + mid + " doesn't exist. Insert failed.",
							"Error", JOptionPane.ERROR_MESSAGE);
					System.out.println("Member with ID " + mid + " doesn't exist. Insert failed.");
					return; // Exit the method, as there's no point in proceeding further
				}
			}

			// Check if the class with the given ID exists
			String classCheckSql = "SELECT * FROM Fitness_Class WHERE Classid = ?";

			try (PreparedStatement classCheckPstmt = con.prepareStatement(classCheckSql)) {
				// Set the value for the parameter
				classCheckPstmt.setString(1, cid);

				// Execute the SELECT query
				ResultSet classCheckResultSet = classCheckPstmt.executeQuery();

				// Check if the class with the given ID exists
				if (!classCheckResultSet.next()) {
					// Class doesn't exist, show an error message
					JOptionPane.showMessageDialog(null, "Class with ID " + cid + " doesn't exist. Insert failed.",
							"Error", JOptionPane.ERROR_MESSAGE);
					System.out.println("Class with ID " + cid + " doesn't exist. Insert failed.");
					return; // Exit the method, as there's no point in proceeding further
				}

				// Check if the member is already enrolled in the class
				String enrollmentCheckSql = "SELECT * FROM Classes WHERE memberid = ? AND Classid = ?";

				try (PreparedStatement enrollmentCheckPstmt = con.prepareStatement(enrollmentCheckSql)) {
					// Set the values for the parameters
					enrollmentCheckPstmt.setString(1, mid);
					enrollmentCheckPstmt.setString(2, cid);

					// Execute the SELECT query
					ResultSet enrollmentCheckResultSet = enrollmentCheckPstmt.executeQuery();

					// Check if the member is already enrolled
					if (enrollmentCheckResultSet.next()) {
						// Member is already enrolled, show an error message
						JOptionPane.showMessageDialog(null, "Member with ID " + mid
								+ " is already enrolled in Class with ID " + cid + ". Insert failed.", "Error",
								JOptionPane.ERROR_MESSAGE);
						System.out.println("Member with ID " + mid + " is already enrolled in Class with ID " + cid
								+ ". Insert failed.");
						return; // Exit the method, as there's no point in proceeding further
					}
				}

				// Check if the class's capacity is not exceeded
				int classCapacity = classCheckResultSet.getInt("capacity");

				// Count the current members in the class
				String countMembersSql = "SELECT COUNT(*) AS memberCount FROM Classes WHERE Classid = ?";
				try (PreparedStatement countMembersPstmt = con.prepareStatement(countMembersSql)) {
					countMembersPstmt.setString(1, cid);
					ResultSet countMembersResultSet = countMembersPstmt.executeQuery();
					countMembersResultSet.next(); // Move to the first row
					int currentMembers = countMembersResultSet.getInt("memberCount");

					if (currentMembers >= classCapacity) {
						// Class capacity exceeded, show an error message
						JOptionPane.showMessageDialog(null,
								"Class with ID " + cid + " has reached its capacity. Insert failed.", "Error",
								JOptionPane.ERROR_MESSAGE);
						System.out.println("Class with ID " + cid + " has reached its capacity. Insert failed.");
						return; // Exit the method, as there's no point in proceeding further
					}

					// Class exists, and capacity is not exceeded, proceed with the INSERT operation
					String insertSql = "INSERT INTO Classes (memberid, Classid) VALUES (?, ?)";

					try (PreparedStatement insertPstmt = con.prepareStatement(insertSql)) {
						// Set the values for the parameters
						insertPstmt.setString(1, mid);
						insertPstmt.setString(2, cid);

						// Execute the INSERT query
						int rowsInserted = insertPstmt.executeUpdate();

						System.out.println("Rows inserted: " + rowsInserted);
					}
				}
			}
		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}

	}

	///////////////////////////////////// Deroll Member ///////////////////////////

	public void derollmember(String mid, String cid) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Check if the member exists in the Membership table
			String memberCheckSql = "SELECT * FROM Membership WHERE id = ?";

			try (PreparedStatement memberCheckPstmt = con.prepareStatement(memberCheckSql)) {
				// Set the value for the parameter
				memberCheckPstmt.setString(1, mid);

				// Execute the SELECT query
				ResultSet memberCheckResultSet = memberCheckPstmt.executeQuery();

				// Check if the member exists
				if (!memberCheckResultSet.next()) {
					// Member doesn't exist, show an error message
					JOptionPane.showMessageDialog(null, "Member with ID " + mid + " doesn't exist. Delete failed.",
							"Error", JOptionPane.ERROR_MESSAGE);
					System.out.println("Member with ID " + mid + " doesn't exist. Delete failed.");
					return; // Exit the method, as there's no point in proceeding further
				}
			}

			// Check if the class with the given ID exists
			String classCheckSql = "SELECT * FROM Fitness_Class WHERE Classid = ?";

			try (PreparedStatement classCheckPstmt = con.prepareStatement(classCheckSql)) {
				// Set the value for the parameter
				classCheckPstmt.setString(1, cid);

				// Execute the SELECT query
				ResultSet classCheckResultSet = classCheckPstmt.executeQuery();

				// Check if the class with the given ID exists
				if (!classCheckResultSet.next()) {
					// Class doesn't exist, show an error message
					JOptionPane.showMessageDialog(null, "Class with ID " + cid + " doesn't exist. Delete failed.",
							"Error", JOptionPane.ERROR_MESSAGE);
					System.out.println("Class with ID " + cid + " doesn't exist. Delete failed.");
					return; // Exit the method, as there's no point in proceeding further
				}

				// Class exists, proceed with the DELETE operation
				String deleteSql = "DELETE FROM Classes WHERE memberid = ? AND Classid = ?";

				try (PreparedStatement deletePstmt = con.prepareStatement(deleteSql)) {
					// Set the values for the parameters
					deletePstmt.setString(1, mid);
					deletePstmt.setString(2, cid);

					// Execute the DELETE query
					int rowsDeleted = deletePstmt.executeUpdate();

					System.out.println("Rows deleted: " + rowsDeleted);
				}
			}
		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	//////////////////////////////////// MARK ATTENDANCE///////////////////////////

	public void mark(String id, String date, String status) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Check if the Member exists in the Membership table
			String trainerCheckSql = "SELECT * FROM Membership WHERE id = ?";

			try (PreparedStatement trainerCheckPstmt = con.prepareStatement(trainerCheckSql)) {
				// Set the value for the parameter
				trainerCheckPstmt.setString(1, id);

				// Execute the SELECT query
				ResultSet trainerCheckResultSet = trainerCheckPstmt.executeQuery();

				// Check if the Member exists
				if (!trainerCheckResultSet.next()) {
					// Member doesn't exist, handle accordingly (e.g., show an error message)
					JOptionPane.showMessageDialog(null, "Member with ID " + id + " doesn't exist. Insert failed.",
							"Error", JOptionPane.ERROR_MESSAGE);
					System.out.println("Member with ID " + id + " doesn't exist. Insert failed.");
					return; // Exit the method, as there's no point in proceeding further
				}
			}

			// Check if the attendance for the given ID and date already exists
			String attendanceCheckSql = "SELECT * FROM attendance WHERE id = ? AND Date = ?";

			try (PreparedStatement attendanceCheckPstmt = con.prepareStatement(attendanceCheckSql)) {
				// Set the values for the parameters
				attendanceCheckPstmt.setString(1, id);
				attendanceCheckPstmt.setString(2, date);

				// Execute the SELECT query
				ResultSet attendanceCheckResultSet = attendanceCheckPstmt.executeQuery();

				// Check if attendance for the given ID and date already exists
				if (attendanceCheckResultSet.next()) {
					JOptionPane.showMessageDialog(null, "Attendance for ID " + id + " on " + date + " already marked.",
							"Error", JOptionPane.ERROR_MESSAGE);
					System.out.println("Attendance for ID " + id + " on " + date + " already marked.");
					return; // Exit the method, as there's no point in proceeding further
				}
			}

			// Member exists, and attendance doesn't exist, proceed with the INSERT
			// operation
			String insertSql = "INSERT INTO attendance (id, Date, status) VALUES (?, ?, ?)";

			try (PreparedStatement insertPstmt = con.prepareStatement(insertSql)) {
				// Set the values for the parameters
				insertPstmt.setString(1, id);
				insertPstmt.setString(2, date);
				insertPstmt.setString(3, status);

				// Execute the INSERT query
				int rowsInserted = insertPstmt.executeUpdate();

				System.out.println("Rows inserted: " + rowsInserted);
			}

		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	//////////////////////////////// Update Attendance//////////////////////////

	public void updatee(String id, String date, String status) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Check if the Member exists in the Membership table
			String trainerCheckSql = "SELECT * FROM Membership WHERE id = ?";

			try (PreparedStatement trainerCheckPstmt = con.prepareStatement(trainerCheckSql)) {
				// Set the value for the parameter
				trainerCheckPstmt.setString(1, id);

				// Execute the SELECT query
				ResultSet trainerCheckResultSet = trainerCheckPstmt.executeQuery();

				// Check if the Member exists
				if (!trainerCheckResultSet.next()) {
					// Member doesn't exist, handle accordingly (e.g., show an error message)
					JOptionPane.showMessageDialog(null, "Member with ID " + id + " doesn't exist. Display failed.",
							"Error", JOptionPane.ERROR_MESSAGE);
					System.out.println("Member with ID " + id + " doesn't exist. Update failed.");
					return; // Exit the method, as there's no point in proceeding further
				}
			}

			// Check if the attendance for the given ID and date already exists
			String attendanceCheckSql = "SELECT * FROM attendance WHERE id = ? AND Date = ?";

			try (PreparedStatement attendanceCheckPstmt = con.prepareStatement(attendanceCheckSql)) {
				// Set the values for the parameters
				attendanceCheckPstmt.setString(1, id);
				attendanceCheckPstmt.setString(2, date);

				// Execute the SELECT query
				ResultSet attendanceCheckResultSet = attendanceCheckPstmt.executeQuery();

				// Check if attendance for the given ID and date already exists
				if (attendanceCheckResultSet.next()) {
					// Attendance exists, proceed with the UPDATE operation
					String updateSql = "UPDATE attendance SET status = ? WHERE id = ? AND Date = ?";

					try (PreparedStatement updatePstmt = con.prepareStatement(updateSql)) {
						// Set the values for the parameters
						updatePstmt.setString(1, status);
						updatePstmt.setString(2, id);
						updatePstmt.setString(3, date);

						// Execute the UPDATE query
						int rowsUpdated = updatePstmt.executeUpdate();

						System.out.println("Rows updated: " + rowsUpdated);
					}
				} else {
					JOptionPane.showMessageDialog(null, "Attendance for ID " + id + " on " + date + " does not exist.",
							"Error", JOptionPane.ERROR_MESSAGE);
					System.out.println("Attendance for ID " + id + " on " + date + " does not exist.");
				}
			}

		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	///////////////////////////////////// Send MSG ////////////////////////////

	public void sendmsg(String id, String msg, String date) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Check if the trainer exists in the Trainer table
			String trainerCheckSql = "SELECT * FROM Membership WHERE id = ?";

			try (PreparedStatement trainerCheckPstmt = con.prepareStatement(trainerCheckSql)) {
				// Set the value for the parameter
				trainerCheckPstmt.setString(1, id);

				// Execute the SELECT query
				ResultSet trainerCheckResultSet = trainerCheckPstmt.executeQuery();

				// Check if the trainer exists
				if (!trainerCheckResultSet.next()) {
					// Trainer doesn't exist, handle accordingly (e.g., show an error message)
					JOptionPane.showMessageDialog(null, "Member with ID " + id + " doesn't exist. Insert failed.",
							"Error", JOptionPane.ERROR_MESSAGE);
					System.out.println("Member with ID " + id + " doesn't exist. Insert failed.");
					return; // Exit the method, as there's no point in proceeding further
				}
			}

			// Trainer is not assigned to a class and Class with the same ID doesn't exist,
			// proceed with the INSERT operation
			String insertSql = "INSERT INTO Alerts (id, message, Date) VALUES (?, ?,?)";

			try (PreparedStatement insertPstmt = con.prepareStatement(insertSql)) {
				// Set the values for the parameters
				insertPstmt.setString(1, id);
				insertPstmt.setString(2, msg);
				insertPstmt.setString(3, date);

				// Execute the INSERT query
				int rowsInserted = insertPstmt.executeUpdate();

				System.out.println("Rows inserted: " + rowsInserted);
			}
		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	public void send_to_all(String msg, String date) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Fetch all member IDs from the Membership table
			String memberIdsSql = "SELECT id FROM Membership";

			try (Statement memberIdsStmt = con.createStatement();
					ResultSet memberIdsResultSet = memberIdsStmt.executeQuery(memberIdsSql)) {
				while (memberIdsResultSet.next()) {
					String memberId = memberIdsResultSet.getString("id");

					// Insert the alert for each member
					String insertAlertSql = "INSERT INTO Alerts (id, message, Date) VALUES (?, ?, ?)";

					try (PreparedStatement insertAlertPstmt = con.prepareStatement(insertAlertSql)) {
						// Set the values for the parameters
						insertAlertPstmt.setString(1, memberId);
						insertAlertPstmt.setString(2, msg); // Assuming textField_1 contains the message
						insertAlertPstmt.setString(3, date); // Assuming textField_2 contains the date

						// Execute the INSERT query for each member
						int rowsInserted = insertAlertPstmt.executeUpdate();

						System.out.println("Rows inserted for member ID " + memberId + ": " + rowsInserted);
					}
				}
			}
		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	public void markattendance(String username, String id, String status) {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			String sql = "SELECT id FROM Member_login WHERE username = ?";

			try (PreparedStatement pstmt = con.prepareStatement(sql)) {
				// Set the value for the parameter
				pstmt.setString(1, username);

				// Execute the SELECT query
				ResultSet resultSet = pstmt.executeQuery();

				if (resultSet.next()) {

					id1 = resultSet.getString("id");
					System.out.println(id);

				} else {

				}
			}

			// Check if the Member exists in the Membership table
			String trainerCheckSql = "SELECT * FROM Membership WHERE id = ?";

			try (PreparedStatement trainerCheckPstmt = con.prepareStatement(trainerCheckSql)) {
				// Set the value for the parameter
				trainerCheckPstmt.setString(1, id);

				// Execute the SELECT query
				ResultSet trainerCheckResultSet = trainerCheckPstmt.executeQuery();

				// Check if the Member exists
				if (id.equals(id1)) {

				} else {
					System.out.println(id);
					JOptionPane.showMessageDialog(null, "Enter your own id", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if (!trainerCheckResultSet.next()) {
					// Member doesn't exist, handle accordingly (e.g., show an error message)
					JOptionPane.showMessageDialog(null, "Member with ID " + id + " doesn't exist. Insert failed.",
							"Error", JOptionPane.ERROR_MESSAGE);
					System.out.println("Member with ID " + id + " doesn't exist. Insert failed.");
					return; // Exit the method, as there's no point in proceeding further
				}
			}

			// Check if the attendance for the given ID and date already exists
			String attendanceCheckSql = "SELECT * FROM attendance WHERE id = ? AND Date = ?";

			try (PreparedStatement attendanceCheckPstmt = con.prepareStatement(attendanceCheckSql)) {
				// Set the values for the parameters
				attendanceCheckPstmt.setString(1, id);
				attendanceCheckPstmt.setString(2, getCurrentDate());

				// Execute the SELECT query
				ResultSet attendanceCheckResultSet = attendanceCheckPstmt.executeQuery();

				// Check if attendance for the given ID and date already exists
				if (attendanceCheckResultSet.next()) {
					JOptionPane.showMessageDialog(null,
							"Attendance for ID " + id + " on " + getCurrentDate() + " already marked.", "Error",
							JOptionPane.ERROR_MESSAGE);
					System.out.println("Attendance for ID " + id + " on " + getCurrentDate() + " already marked.");
					return; // Exit the method, as there's no point in proceeding further
				}
			}

			// Member exists, and attendance doesn't exist, proceed with the INSERT
			// operation
			String insertSql = "INSERT INTO attendance (id, Date, status) VALUES (?, ?, ?)";

			try (PreparedStatement insertPstmt = con.prepareStatement(insertSql)) {
				// Set the values for the parameters
				insertPstmt.setString(1, id);
				insertPstmt.setString(2, getCurrentDate());
				insertPstmt.setString(3, status);

				// Execute the INSERT query
				int rowsInserted = insertPstmt.executeUpdate();

				System.out.println("Rows inserted: " + rowsInserted);
			}

		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}

	}

	public void member_registration(String username, String password, String id) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Check if the ID exists in the Membership table
			String membershipCheckSql = "SELECT * FROM Membership WHERE id = ?";
			try (PreparedStatement membershipCheckPstmt = con.prepareStatement(membershipCheckSql)) {
				// Set the value for the parameter
				membershipCheckPstmt.setString(1, id);

				// Execute the SELECT query
				ResultSet membershipCheckResultSet = membershipCheckPstmt.executeQuery();

				// Check if the ID exists in the Membership table
				if (!membershipCheckResultSet.next()) {
					// ID not found in the Membership table, show an error message
					JOptionPane.showMessageDialog(null, "Member with ID " + id + " doesn't have a Membership.", "Error",
							JOptionPane.ERROR_MESSAGE);
					System.out.println("Member with ID " + id + " doesn't have a Membership.");
					return; // Exit the method, as there's no point in proceeding further
				}
			}

			// Check if the ID does not exist in the Member_login table
			String memberLoginCheckIdSql = "SELECT * FROM Member_login WHERE id = ?";
			try (PreparedStatement memberLoginCheckIdPstmt = con.prepareStatement(memberLoginCheckIdSql)) {
				// Set the value for the parameter
				memberLoginCheckIdPstmt.setString(1, id);

				// Execute the SELECT query
				ResultSet memberLoginCheckIdResultSet = memberLoginCheckIdPstmt.executeQuery();

				// Check if the ID does not exist in the Member_login table
				if (memberLoginCheckIdResultSet.next()) {
					// ID already exists in the Member_login table, show an error message
					JOptionPane.showMessageDialog(null, "Member with ID " + id + " is already registered.", "Error",
							JOptionPane.ERROR_MESSAGE);
					System.out.println("Member with ID " + id + " is already registered.");
					return; // Exit the method, as there's no point in proceeding further
				}
			}

			// Check if the username does not exist in the Member_login table
			String memberLoginCheckUsernameSql = "SELECT * FROM Member_login WHERE username = ?";
			try (PreparedStatement memberLoginCheckUsernamePstmt = con.prepareStatement(memberLoginCheckUsernameSql)) {
				// Set the value for the parameter
				memberLoginCheckUsernamePstmt.setString(1, username);

				// Execute the SELECT query
				ResultSet memberLoginCheckUsernameResultSet = memberLoginCheckUsernamePstmt.executeQuery();

				// Check if the username does not exist in the Member_login table
				if (memberLoginCheckUsernameResultSet.next()) {
					// Username already exists in the Member_login table, show an error message
					JOptionPane.showMessageDialog(null,
							"Username " + username + " is already taken. Choose a different username.", "Error",
							JOptionPane.ERROR_MESSAGE);
					System.out.println("Username " + username + " is already taken. Choose a different username.");
					return; // Exit the method, as there's no point in proceeding further
				}
			}

			// ID exists in Membership table, ID does not exist in Member_login table, and
			// username does not exist in Member_login table
			// Proceed with the INSERT operation
			String insertSql = "INSERT INTO Member_login (username, password, id) VALUES (?, ?, ?)";
			try (PreparedStatement insertPstmt = con.prepareStatement(insertSql)) {
				// Set the values for the parameters
				insertPstmt.setString(1, username);
				insertPstmt.setString(2, password);
				insertPstmt.setString(3, id);

				// Execute the INSERT query
				int rowsInserted = insertPstmt.executeUpdate();

				System.out.println("Rows inserted: " + rowsInserted);
			}
		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	public void memberlogin(String username, String password) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Use PreparedStatement to safely handle parameters and prevent SQL injection
			String sql = "SELECT * FROM Member_login WHERE username = ? AND password = ?";

			try (PreparedStatement pstmt = con.prepareStatement(sql)) {
				// Set the values for the parameters
				pstmt.setString(1, username);
				pstmt.setString(2, password);

				// Execute the query
				ResultSet resultSet = pstmt.executeQuery();

				if (resultSet.next()) {

					System.out.println("Login Succssful");
					Member window5 = new Member();
					window5.frame.setVisible(true);
					window5.setname(username);
					Member_login w=new Member_login();
					w.frame.dispose();
					// Match found, open the FrontDeskStaff window or perform other actions
					// FrontDeskStaff FrontDeskStaff= new FrontDeskStaff();
					// frame.dispose();

				} else {
					JOptionPane.showMessageDialog(null, "Wrong password or username", "Error",
							JOptionPane.ERROR_MESSAGE);
					System.out.println("Wrong id or username");
					// JOptionPane.showMessageDialog(this, "Username or Password is wrong...");
				}
			}
		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	public void Trainerlogin(String username, String password) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Use PreparedStatement to safely handle parameters and prevent SQL injection
			String sql = "SELECT * FROM Trainer WHERE username = ? AND password = ?";

			try (PreparedStatement pstmt = con.prepareStatement(sql)) {
				// Set the values for the parameters
				pstmt.setString(1, username);
				pstmt.setString(2, password);

				// Execute the query
				ResultSet resultSet = pstmt.executeQuery();

				if (resultSet.next()) {

					System.out.println("Login Succssful");
					Trainer window7 = new Trainer();
					window7.frame.setVisible(true);
					window7.setname(username);
					Trainer_login w=new Trainer_login();
					w.frame.dispose();
					// Match found, open the FrontDeskStaff window or perform other actions
					// FrontDeskStaff FrontDeskStaff= new FrontDeskStaff();
					// frame.dispose();

				} else {

					JOptionPane.showMessageDialog(null, "Wrong password or username", "Error",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	public void frontdesklogin(String username, String password) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

			// Use PreparedStatement to safely handle parameters and prevent SQL injection
			String sql = "SELECT * FROM frontdesk_login WHERE username = ? AND password = ?";

			try (PreparedStatement pstmt = con.prepareStatement(sql)) {
				// Set the values for the parameters
				pstmt.setString(1, username);
				pstmt.setString(2, password);

				// Execute the query
				ResultSet resultSet = pstmt.executeQuery();

				if (resultSet.next()) {

					System.out.println("Login Succssful");
					FrontDeskStaff window6 = new FrontDeskStaff();
					window6.frame.setVisible(true);
					frame.dispose();
					FrontDesk_login w=new FrontDesk_login();
					w.frame.dispose();  
					// Match found, open the FrontDeskStaff window or perform other actions
					// FrontDeskStaff FrontDeskStaff= new FrontDeskStaff();
					// frame.dispose();

				} else {

					JOptionPane.showMessageDialog(null, "Wrong password or username", "Error",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		} catch (Exception ee) {
			ee.printStackTrace(); // Handle exceptions properly in a real application
		}
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DB_CLASS1 window = new DB_CLASS1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
