create database sda;
use sda;
create table frontdesk_login( username varchar(255), password varchar(255),id varchar(255),name varchar(255),contact varchar(255));
drop table frontdesk_login;
INSERT INTO frontdesk_login(username,password,id,name,contact) VALUES('Zalan','54321','3301','Zalan','98765430020');
select * from frontdesk_login;
create table Member_login( username varchar(255), password varchar(255),id varchar(255));
INSERT INTO Member_login(username,password,id) VALUES('hi','54321','9900');
select * from Member_login;
Drop table Member_login;

create table Membership( id varchar(255),name varchar(255),contact varchar(255), type varchar(255));
select * from Membership;

create table Inventory(id varchar(255), name varchar(255), Status varchar(255));
INSERT INTO Inventory(id,name,status) VALUES('1','1kg Dumbell','working');
select * from Inventory;

create table trainer_login( username varchar(255), password varchar(255));
drop table trainer_login;
INSERT INTO trainer_login(username,password) VALUES('misbah','54321');
INSERT INTO trainer_login(username,password) VALUES('arsalan','12345');
select * from trainer_login;

create table Trainer( username varchar(255), password varchar(255),id varchar(255), name varchar(255), contact varchar(255));
INSERT INTO Trainer(username,password,id,name,contact) VALUES('misbah','54321','1101','Misbah','12345678903');
INSERT INTO Trainer(username,password,id,name,contact) VALUES('arsalan','12345','1102','Arsalan','09876543214');
INSERT INTO Trainer(username,password,id,name,contact) VALUES('osama','12345','1103','Osama','07326543214');
INSERT INTO Trainer(username,password,id,name,contact) VALUES('huzaifa','12345','1104','Huzaifa','09876597214');
Drop table Trainer;
select* from Trainer;

create table Fitness_Class( Classid varchar(255), name varchar(255), Capacity varchar(255), TrainerID varchar(255));
select * from Fitness_Class;

create table Classes(memberid varchar(255), Classid varchar(255));
select * from Classes;
drop table Classes;


create table payment(id varchar(255), amount varchar(255), Date varchar(255));
select * from Membership order by id asc;
insert into payment(id,amount,Date) values('9900','2000','25-11-20203'),
('9901','4000','25-11-2023'),
('9902','4000','25-11-2023'),
('9903','4000','25-10-2023'),
('9904','2000','22-11-2023'),
('9905','4000','25-11-2023'),
('9906','2000','24-11-2023'),
('9907','2000','20-11-2023'),
('9908','2000','18-11-2023'),
('9909','4000','21-11-2023'),
('9910','4000','22-11-2023');

select * from payment;
drop table payment;

create table Alerts(id varchar(255), message varchar(255), Date varchar(255));
select * from Alerts order by id asc;

create table attendance(id varchar(255), Date varchar(255), status varchar(255));