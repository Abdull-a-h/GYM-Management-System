package BUI_Package;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Trainer {

	public JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTable table;
	private JTextField textField_3;
	private JTextField textField_4;
	protected String name;
	private JTextField textField_5;
	public void setname(String name1) {
		name=name1;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Trainer window = new Trainer();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Trainer() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 733, 492);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Trainer");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblNewLabel.setBounds(308, 27, 86, 26);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("TrainerID");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_1.setBounds(45, 83, 72, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Name");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_2.setBounds(45, 119, 49, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Contact");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_3.setBounds(45, 159, 49, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setBounds(127, 80, 127, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(127, 116, 128, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(127, 156, 128, 20);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnNewButton = new JButton("View Inventory");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				    Class.forName("com.mysql.cj.jdbc.Driver");
				    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

				    String sql = "SELECT * FROM inventory";

				    try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
				        ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();
				        DefaultTableModel model = (DefaultTableModel) table.getModel();
				        
				        model.setRowCount(0);

				        int cols = rsmd.getColumnCount();
				        String[] colName = new String[cols];
				        
				        // Populate column names
				        for (int i = 0; i < cols; i++)
				            colName[i] = rsmd.getColumnName(i + 1);
				        
				        model.setColumnIdentifiers(colName);

				        // Populate table data
				        while (rs.next()) {
				            Object[] row = new Object[cols];
				            for (int i = 0; i < cols; i++)
				                row[i] = rs.getObject(i + 1);
				            
				            model.addRow(row);
				        }
				    } // The try-with-resources statement automatically closes the ResultSet, Statement, and Connection

				} catch (Exception ee) {
				    ee.printStackTrace(); // Handle exceptions properly in a real application
				}

			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton.setBounds(81, 184, 142, 23);
		frame.getContentPane().add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(283, 83, 397, 339);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel_4 = new JLabel("TrainerID");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_4.setBounds(34, 295, 72, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		textField_3 = new JTextField();
		textField_3.setBounds(127, 293, 127, 20);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("GetInfo");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				    Class.forName("com.mysql.cj.jdbc.Driver");
				    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");
				    
				    String classCheckSql1 = "SELECT * FROM Trainer WHERE username = ? AND id=?";
					 

				    try (PreparedStatement classCheckPstmt1 = con.prepareStatement(classCheckSql1)) {
				        // Set the value for the parameter
				        classCheckPstmt1.setString(1, name);
				        classCheckPstmt1.setString(2, textField_3.getText());

				        // Execute the SELECT query
				        ResultSet classCheckResultSet1 = classCheckPstmt1.executeQuery();

				        // Check if the class exists
				        if (!classCheckResultSet1.next()) {
				            // Member doesn't exist, handle accordingly (e.g., show an error message)
				        	JOptionPane.showMessageDialog(null, "Wrong ID entered.", "Error", JOptionPane.ERROR_MESSAGE);
				            System.out.println("Member with ID " + textField_3.getText() + " doesn't exist. Display failed.");
				            return; // Exit the method, as there's no point in proceeding further
				        }
				    }

				    // Use PreparedStatement to safely handle parameters and prevent SQL injection
				    String selectSql = "SELECT * FROM Trainer WHERE id = ?";
				    
				    try (PreparedStatement selectPstmt = con.prepareStatement(selectSql)) {
				        // Set the value for the parameter
				        selectPstmt.setString(1, textField_3.getText());

				        // Execute the SELECT query
				        ResultSet resultSet = selectPstmt.executeQuery();

				        // Check if the ID exists
				        if (resultSet.next()) {
				            // ID found, retrieve data from columns
				        	String id=resultSet.getString("id");
				            String name = resultSet.getString("name");
				            String contact = resultSet.getString("contact");
				            
				            
				            // Do something with the retrieved data (e.g., display or store in variables)
				            textField.setText(id);
		                    textField_1.setText(name);
		                    textField_2.setText(contact);
		                    
				        } else {
				            // ID not found, handle accordingly (e.g., show an error message)
				        	JOptionPane.showMessageDialog(null, "ID not found", "Error", JOptionPane.ERROR_MESSAGE);
				            System.out.println("ID not found.");
				            textField.setText("");
		                    textField_1.setText("");
		                    textField_2.setText("");
		                    textField_3.setText("");
				        }
				    }
				} catch (Exception ee) {
				    ee.printStackTrace(); // Handle exceptions properly in a real application
				}
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_1.setBounds(81, 334, 99, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_5 = new JLabel("ItemID");
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_5.setBounds(34, 220, 49, 14);
		frame.getContentPane().add(lblNewLabel_5);
		
		textField_4 = new JTextField();
		textField_4.setBounds(127, 218, 127, 20);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("GetStatus");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				    Class.forName("com.mysql.cj.jdbc.Driver");
				    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

				    // Use PreparedStatement to safely handle parameters and prevent SQL injection
				    String selectSql = "SELECT * FROM Inventory WHERE id = ?";
				    
				    try (PreparedStatement selectPstmt = con.prepareStatement(selectSql)) {
				        // Set the value for the parameter
				        selectPstmt.setString(1, textField_4.getText());

				        // Execute the SELECT query
				        ResultSet resultSet = selectPstmt.executeQuery();

				        // Check if the ID exists
				        if (resultSet.next()) {
				            // ID found, retrieve data from columns
				        	String id=resultSet.getString("id");
				           // String name = resultSet.getString("name");
				            String status = resultSet.getString("status");
				            
				            
				            // Do something with the retrieved data (e.g., display or store in variables)
				            
		                    textField_4.setText("ID="+id+" "+status);
		                    
				        } else {
				            // ID not found, handle accordingly (e.g., show an error message)
				        	JOptionPane.showMessageDialog(null, "ID not found", "Error", JOptionPane.ERROR_MESSAGE);
				            System.out.println("ID not found.");
				           
		                    textField_2.setText("");
		                    
				        }
				    }
				} catch (Exception ee) {
				    ee.printStackTrace(); // Handle exceptions properly in a real application
				}
			}
		});
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_2.setBounds(81, 259, 99, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		JLabel lblNewLabel_6 = new JLabel("←");
		lblNewLabel_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				GYM window3 =new GYM();
				window3.frame.setVisible(true);
				frame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 40));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 30));
			}
		});
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel_6.setBounds(10, 11, 49, 20);
		frame.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("ClassID");
		lblNewLabel_7.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_7.setBounds(39, 370, 55, 14);
		frame.getContentPane().add(lblNewLabel_7);
		
		textField_5 = new JTextField();
		textField_5.setBounds(127, 368, 127, 20);
		frame.getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		JButton btnNewButton_3 = new JButton("View Enrollment");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				    Class.forName("com.mysql.cj.jdbc.Driver");
				    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

				    // Check if the class exists in the Fitness_Class table
				    String classCheckSql = "SELECT * FROM Fitness_Class WHERE Classid = ?";

				    try (PreparedStatement classCheckPstmt = con.prepareStatement(classCheckSql)) {
				        // Set the value for the parameter
				        classCheckPstmt.setString(1, textField_5.getText());

				        // Execute the SELECT query
				        ResultSet classCheckResultSet = classCheckPstmt.executeQuery();

				        // Check if the class exists
				        if (!classCheckResultSet.next()) {
				            // Class doesn't exist, handle accordingly (e.g., show an error message)
				            JOptionPane.showMessageDialog(null, "Class with ID " + textField_5.getText() + " doesn't exist. Display failed.", "Error", JOptionPane.ERROR_MESSAGE);
				            System.out.println("Class with ID " + textField_5.getText() + " doesn't exist. Display failed.");
				            return; // Exit the method, as there's no point in proceeding further
				        }
				    }

				    // Fetch and display the member information for the provided class ID
				    String sql = "SELECT Membership.id, Membership.name, Membership.contact FROM Membership JOIN Classes ON Membership.id = Classes.memberid WHERE Classes.Classid = ? ORDER BY Membership.id ASC";

				    try (PreparedStatement pstmt = con.prepareStatement(sql)) {
				        // Set the value for the parameter
				        pstmt.setString(1, textField_5.getText());

				        // Execute the SELECT query
				        ResultSet rs = pstmt.executeQuery();

				        // Display the member information in the table
				        ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();
				        DefaultTableModel model = (DefaultTableModel) table.getModel();

				        model.setRowCount(0);

				        int cols = rsmd.getColumnCount();
				        String[] colName = new String[cols];

				        // Populate column names
				        for (int i = 0; i < cols; i++)
				            colName[i] = rsmd.getColumnName(i + 1);

				        model.setColumnIdentifiers(colName);

				        // Populate table data
				        while (rs.next()) {
				            Object[] row = new Object[cols];
				            for (int i = 0; i < cols; i++)
				                row[i] = rs.getObject(i + 1);

				            model.addRow(row);
				        }
				    }
				} catch (Exception ee) {
				    ee.printStackTrace(); // Handle exceptions properly in a real application
				}

			}
		});
		btnNewButton_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_3.setBounds(81, 399, 138, 23);
		frame.getContentPane().add(btnNewButton_3);
	}

}
