package BUI_Package;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import DB__package.DB_CLASS1;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Inventory {

	JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTable table;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Inventory window = new Inventory();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Inventory() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 626, 427);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Inventory");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblNewLabel.setBounds(210, 11, 120, 38);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ID");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_1.setBounds(50, 73, 49, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Name");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_2.setBounds(50, 104, 49, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Status");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_3.setBounds(50, 135, 49, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setBounds(109, 71, 126, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(109, 102, 126, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(109, 133, 126, 20);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnNewButton = new JButton("ViewInventory");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				    Class.forName("com.mysql.cj.jdbc.Driver");
				    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

				    String sql = "SELECT * FROM inventory";

				    try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
				        ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();
				        DefaultTableModel model = (DefaultTableModel) table.getModel();
				        
				        model.setRowCount(0);

				        int cols = rsmd.getColumnCount();
				        String[] colName = new String[cols];
				        
				        // Populate column names
				        for (int i = 0; i < cols; i++)
				            colName[i] = rsmd.getColumnName(i + 1);
				        
				        model.setColumnIdentifiers(colName);

				        // Populate table data
				        while (rs.next()) {
				            Object[] row = new Object[cols];
				            for (int i = 0; i < cols; i++)
				                row[i] = rs.getObject(i + 1);
				            
				            model.addRow(row);
				        }
				    } // The try-with-resources statement automatically closes the ResultSet, Statement, and Connection

				} catch (Exception ee) {
				    ee.printStackTrace(); // Handle exceptions properly in a real application
				}


			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton.setBounds(73, 172, 136, 23);
		frame.getContentPane().add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(277, 73, 325, 283);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnNewButton_1 = new JButton("Add Item");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id=textField.getText();
				String name=textField_1.getText();
				String status=textField_2.getText();
			
				
				DB_CLASS1.getinstance().viewmessage();
				DB_CLASS1.getinstance().additem(id,name,status);

			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_1.setBounds(73, 206, 136, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Change Status");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id=textField.getText();
				
				String status=textField_2.getText();
			
				
				DB_CLASS1.getinstance().viewmessage();
				DB_CLASS1.getinstance().changestatus(id,status);
				////////////////////////////////////////
			}
		});
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_2.setBounds(73, 240, 136, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Delete Item");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id=textField_3.getText();
				
				
			
				
				DB_CLASS1.getinstance().viewmessage();
				DB_CLASS1.getinstance().deleteitem(id);
			}
		});
		btnNewButton_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_3.setBounds(144, 329, 112, 23);
		frame.getContentPane().add(btnNewButton_3);
		
		JLabel lblNewLabel_4 = new JLabel("ID");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_4.setBounds(38, 288, 49, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		textField_3 = new JTextField();
		textField_3.setBounds(109, 286, 126, 20);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnNewButton_4 = new JButton("Search");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				    Class.forName("com.mysql.cj.jdbc.Driver");
				    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

				    // Use PreparedStatement to safely handle parameters and prevent SQL injection
				    String selectSql = "SELECT * FROM Inventory WHERE id = ?";
				    
				    try (PreparedStatement selectPstmt = con.prepareStatement(selectSql)) {
				        // Set the value for the parameter
				        selectPstmt.setString(1, textField_3.getText());

				        // Execute the SELECT query
				        ResultSet resultSet = selectPstmt.executeQuery();

				        // Check if the ID exists
				        if (resultSet.next()) {
				            // ID found, retrieve data from columns
				        	String id=resultSet.getString("id");
				            String name = resultSet.getString("name");
				            String status = resultSet.getString("status");
				            
				            
				            // Do something with the retrieved data (e.g., display or store in variables)
				            textField.setText(id);
		                    textField_1.setText(name);
		                    textField_2.setText(status);
		                    
				        } else {
				            // ID not found, handle accordingly (e.g., show an error message)
				            System.out.println("ID not found.");
				            textField.setText("");
		                    textField_1.setText("");
		                    textField_2.setText("");
		                    textField_3.setText("");
				        }
				    }
				} catch (Exception ee) {
				    ee.printStackTrace(); // Handle exceptions properly in a real application
				}
			}
		});
		btnNewButton_4.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_4.setBounds(21, 329, 112, 23);
		frame.getContentPane().add(btnNewButton_4);
		
		JLabel lblNewLabel_5 = new JLabel("←");
		lblNewLabel_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				FrontDeskStaff window6 =new FrontDeskStaff();
				window6.frame.setVisible(true);
				frame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				
				lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 40));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				
				lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 30));
			}
		});
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel_5.setBounds(10, 11, 55, 20);
		frame.getContentPane().add(lblNewLabel_5);
	}
}
