package BUI_Package;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import DB__package.DB_CLASS1;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Payment {

	JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Payment window = new Payment();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Payment() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private String getCurrentDate() {
	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    return dateFormat.format(new Date());
	}
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 512, 352);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("PAYMENT");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel.setBounds(207, 38, 84, 17);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ID");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_1.setBounds(112, 89, 60, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Amount");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_2.setBounds(112, 126, 60, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Date");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_3.setBounds(112, 170, 60, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setBounds(182, 87, 149, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(182, 124, 149, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(182, 168, 149, 20);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("ID");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_4.setBounds(123, 235, 49, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		textField_3 = new JTextField();
		textField_3.setBounds(182, 233, 149, 20);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnNewButton = new JButton("Generate Bill");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				    Class.forName("com.mysql.cj.jdbc.Driver");
				    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

				    // Use PreparedStatement to safely handle parameters and prevent SQL injection
				    String selectSql = "SELECT * FROM Membership WHERE id = ?";

				    try (PreparedStatement selectPstmt = con.prepareStatement(selectSql)) {
				        // Set the value for the parameter
				        selectPstmt.setString(1, textField_3.getText());

				        // Execute the SELECT query
				        ResultSet resultSet = selectPstmt.executeQuery();

				        // Check if the ID exists in the Membership table
				        if (resultSet.next()) {
				            // ID found, retrieve data from columns
				            String membershipType = resultSet.getString("type");
				            
				            // Check the membership type
				            if ("Gym".equals(membershipType)) {
				                // Display amount of 2000 and current date
				                textField.setText(textField_3.getText());
				                textField_1.setText("2000");
				                textField_2.setText(getCurrentDate()); // Assuming you have a method to get the current date
				            } else if ("Gym+Cardio".equals(membershipType)) {
				                // Display amount of 4000 and current date
				                textField.setText(textField_3.getText());
				                textField_1.setText("4000");
				                textField_2.setText(getCurrentDate()); // Assuming you have a method to get the current date
				            } else {
				                // Handle other membership types if needed
				                System.out.println("Unsupported membership type: " + membershipType);
				            }
				        } else {
				            // ID not found, handle accordingly (e.g., show an error message)
				            System.out.println("ID not found.");
				            textField.setText("");
				            textField_1.setText("");
				            textField_2.setText("");
				            textField_3.setText("");
				        }
				    }
				} catch (Exception ee) {
				    ee.printStackTrace(); // Handle exceptions properly in a real application
				}

				// Additional method to get the current date (you can use your own method or library)
				

				
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton.setBounds(101, 270, 126, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Payment");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id=textField.getText();
				String amount=textField_1.getText();
				String date=textField_2.getText();
				
				
				DB_CLASS1.getinstance().viewmessage();
				DB_CLASS1.getinstance().payment(id,amount,date);

			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_1.setBounds(145, 199, 108, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Update");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id=textField.getText();
				String amount=textField_1.getText();
				String date=textField_2.getText();
				
				
				DB_CLASS1.getinstance().viewmessage();
				DB_CLASS1.getinstance().update(id,amount,date);

				
			}
		});
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_2.setBounds(280, 199, 108, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		JLabel lblNewLabel_5 = new JLabel("←");
		lblNewLabel_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				FrontDeskStaff window6 =new FrontDeskStaff();
				window6.frame.setVisible(true);
				frame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				
				lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 40));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				
				lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 30));
			}
		});
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel_5.setBounds(10, 11, 54, 20);
		frame.getContentPane().add(lblNewLabel_5);
		
		JButton btnNewButton_3 = new JButton("View Payment");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				    Class.forName("com.mysql.cj.jdbc.Driver");
				    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

				    // Use PreparedStatement to safely handle parameters and prevent SQL injection
				    String selectSql = "SELECT * FROM payment WHERE id = ?";
				    
				    try (PreparedStatement selectPstmt = con.prepareStatement(selectSql)) {
				        // Set the value for the parameter
				        selectPstmt.setString(1, textField_3.getText());

				        // Execute the SELECT query
				        ResultSet resultSet = selectPstmt.executeQuery();

				        // Check if the ID exists
				        if (resultSet.next()) {
				            // ID found, retrieve data from columns
				        	String id=resultSet.getString("id");
				            String amount = resultSet.getString("amount");
				            String Date = resultSet.getString("Date");
				           
				            
				            // Do something with the retrieved data (e.g., display or store in variables)
				            textField.setText(id);
		                    textField_1.setText(amount);
		                    textField_2.setText(Date);
		                    
				        } else {
				            // ID not found, handle accordingly (e.g., show an error message)
				        	JOptionPane.showMessageDialog(null, "ID not found.", "Error", JOptionPane.ERROR_MESSAGE);
				            System.out.println("ID not found.");
				            textField.setText("");
		                    textField_1.setText("");
		                    textField_2.setText("");
		                    
				        }
				    }
				} catch (Exception ee) {
				    ee.printStackTrace(); // Handle exceptions properly in a real application
				}
			}
		});
		btnNewButton_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_3.setBounds(248, 270, 126, 23);
		frame.getContentPane().add(btnNewButton_3);
	}
}
