package BUI_Package;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import DB__package.DB_CLASS1;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Fitness_Class {

	JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Fitness_Class window = new Fitness_Class();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Fitness_Class() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 709, 483);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Fitness Class");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblNewLabel.setBounds(272, 11, 142, 26);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ClassID");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_1.setBounds(49, 60, 62, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Name");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_2.setBounds(49, 85, 49, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Capacity");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_3.setBounds(49, 110, 62, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("TrainerID");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_4.setBounds(49, 135, 71, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		textField = new JTextField();
		textField.setBounds(121, 58, 129, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(121, 83, 129, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(121, 108, 129, 20);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(121, 133, 129, 20);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("ClassID");
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_1_1.setBounds(73, 314, 62, 14);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		textField_4 = new JTextField();
		textField_4.setBounds(154, 308, 96, 20);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		JButton btnNewButton = new JButton("View Enrolment");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				    Class.forName("com.mysql.cj.jdbc.Driver");
				    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

				    // Check if the class exists in the Fitness_Class table
				    String classCheckSql = "SELECT * FROM Fitness_Class WHERE Classid = ?";

				    try (PreparedStatement classCheckPstmt = con.prepareStatement(classCheckSql)) {
				        // Set the value for the parameter
				        classCheckPstmt.setString(1, textField_4.getText());

				        // Execute the SELECT query
				        ResultSet classCheckResultSet = classCheckPstmt.executeQuery();

				        // Check if the class exists
				        if (!classCheckResultSet.next()) {
				            // Class doesn't exist, handle accordingly (e.g., show an error message)
				            JOptionPane.showMessageDialog(null, "Class with ID " + textField_4.getText() + " doesn't exist. Display failed.", "Error", JOptionPane.ERROR_MESSAGE);
				            System.out.println("Class with ID " + textField_4.getText() + " doesn't exist. Display failed.");
				            return; // Exit the method, as there's no point in proceeding further
				        }
				    }

				    // Fetch and display the member information for the provided class ID
				    String sql = "SELECT Membership.id, Membership.name, Membership.contact FROM Membership JOIN Classes ON Membership.id = Classes.memberid WHERE Classes.Classid = ? ORDER BY Membership.id ASC";

				    try (PreparedStatement pstmt = con.prepareStatement(sql)) {
				        // Set the value for the parameter
				        pstmt.setString(1, textField_4.getText());

				        // Execute the SELECT query
				        ResultSet rs = pstmt.executeQuery();

				        // Display the member information in the table
				        ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();
				        DefaultTableModel model = (DefaultTableModel) table.getModel();

				        model.setRowCount(0);

				        int cols = rsmd.getColumnCount();
				        String[] colName = new String[cols];

				        // Populate column names
				        for (int i = 0; i < cols; i++)
				            colName[i] = rsmd.getColumnName(i + 1);

				        model.setColumnIdentifiers(colName);

				        // Populate table data
				        while (rs.next()) {
				            Object[] row = new Object[cols];
				            for (int i = 0; i < cols; i++)
				                row[i] = rs.getObject(i + 1);

				            model.addRow(row);
				        }
				    }
				} catch (Exception ee) {
				    ee.printStackTrace(); // Handle exceptions properly in a real application
				}

				
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton.setBounds(100, 373, 150, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("View Classes");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				    Class.forName("com.mysql.cj.jdbc.Driver");
				    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

				    String sql = "SELECT * FROM Fitness_class";

				    try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
				        ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();
				        DefaultTableModel model = (DefaultTableModel) table.getModel();
				        
				        model.setRowCount(0);

				        int cols = rsmd.getColumnCount();
				        String[] colName = new String[cols];
				        
				        // Populate column names
				        for (int i = 0; i < cols; i++)
				            colName[i] = rsmd.getColumnName(i + 1);
				        
				        model.setColumnIdentifiers(colName);

				        // Populate table data
				        while (rs.next()) {
				            Object[] row = new Object[cols];
				            for (int i = 0; i < cols; i++)
				                row[i] = rs.getObject(i + 1);
				            
				            model.addRow(row);
				        }
				    } // The try-with-resources statement automatically closes the ResultSet, Statement, and Connection

				} catch (Exception ee) {
				    ee.printStackTrace(); // Handle exceptions properly in a real application
				}
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_1.setBounds(100, 412, 150, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_5 = new JLabel("MemberID");
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_5.setBounds(93, 194, 77, 14);
		frame.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("ClassID");
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_6.setBounds(93, 219, 71, 14);
		frame.getContentPane().add(lblNewLabel_6);
		
		textField_5 = new JTextField();
		textField_5.setBounds(174, 192, 96, 20);
		frame.getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBounds(174, 217, 96, 20);
		frame.getContentPane().add(textField_6);
		textField_6.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("Enroll Member");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				String mid=textField_5.getText();
				String cid=textField_6.getText();
				
				
				DB_CLASS1.getinstance().viewmessage();
				DB_CLASS1.getinstance().enrollmember(mid,cid);

				
			}
		});
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_2.setBounds(100, 244, 142, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Add Class");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String classid=textField.getText();
				String name=textField_1.getText();
				String capacity=textField_2.getText();
				String trainerid=textField_3.getText();
				
				DB_CLASS1.getinstance().viewmessage();
				DB_CLASS1.getinstance().addclass(classid,name,capacity,trainerid);



			}
		});
		btnNewButton_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_3.setBounds(25, 164, 110, 23);
		frame.getContentPane().add(btnNewButton_3);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(291, 60, 381, 336);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel_7 = new JLabel("←");
		lblNewLabel_7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				FrontDeskStaff window6 =new FrontDeskStaff();
				window6.frame.setVisible(true);
				frame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				
				lblNewLabel_7.setFont(new Font("Times New Roman", Font.BOLD, 40));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblNewLabel_7.setFont(new Font("Times New Roman", Font.BOLD, 30));
			}
		});
		lblNewLabel_7.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel_7.setBounds(10, 8, 55, 26);
		frame.getContentPane().add(lblNewLabel_7);
		
		JButton btnNewButton_4 = new JButton("Update Class");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				String classid=textField.getText();
				String name=textField_1.getText();
				String capacity=textField_2.getText();
				String trainerid=textField_3.getText();
				
				DB_CLASS1.getinstance().viewmessage();
				DB_CLASS1.getinstance().updateclass(classid,name,capacity,trainerid);

			}
		});
		btnNewButton_4.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_4.setBounds(145, 164, 125, 23);
		frame.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Delete Class");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String classid=textField_4.getText();
				
				
				DB_CLASS1.getinstance().viewmessage();
				DB_CLASS1.getinstance().deleteclass(classid);
			}
		});
		btnNewButton_5.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_5.setBounds(100, 339, 150, 23);
		frame.getContentPane().add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("Deroll Member");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				
				String mid=textField_5.getText();
				String cid=textField_6.getText();
				
				
				DB_CLASS1.getinstance().viewmessage();
				DB_CLASS1.getinstance().derollmember(mid,cid);
				

			}
		});
		btnNewButton_6.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_6.setBounds(100, 276, 142, 23);
		frame.getContentPane().add(btnNewButton_6);
	}

}
