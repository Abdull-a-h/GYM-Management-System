package BUI_Package;

import java.awt.EventQueue;
import java.sql.*;
import DB__package.DB_CLASS1;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.result.ResultSetMetaData;



import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollBar;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class Membership {

	JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Membership window = new Membership();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Membership() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 690, 501);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Membership");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 28));
		lblNewLabel.setBounds(232, 21, 173, 33);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Id");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_1.setBounds(92, 79, 49, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Name");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_2.setBounds(92, 114, 49, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Contact");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_3.setBounds(92, 150, 49, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Type");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_4.setBounds(92, 184, 49, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		textField = new JTextField();
		textField.setBounds(157, 76, 134, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(157, 111, 134, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(157, 147, 134, 20);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(157, 181, 134, 20);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnNewButton = new JButton("Register");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id=textField.getText();
				String name=textField_1.getText();
				String contact=textField_2.getText();
				String type=textField_3.getText();
				
				DB_CLASS1.getinstance().viewmessage();
				DB_CLASS1.getinstance().RegisterMemberhip(id,name,contact,type);

			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 11));
		btnNewButton.setBounds(71, 233, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Update");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				String id=textField.getText();
				String name=textField_1.getText();
				String contact=textField_2.getText();
				String type=textField_3.getText();
				
				DB_CLASS1.getinstance().viewmessage();
				DB_CLASS1.getinstance().UpdateMemberhip(id,name,contact,type);


				//HEEEELLLLDDJS
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_1.setBounds(183, 233, 89, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Cancel");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 
				String id=textField_4.getText();
				
				
				DB_CLASS1.getinstance().viewmessage();
				DB_CLASS1.getinstance().deletemembers(id);

				/////////////////////////////////////
			}
		});
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_2.setBounds(71, 288, 89, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		textField_4 = new JTextField();
		textField_4.setBounds(164, 341, 127, 20);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("ID");
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_5.setBounds(92, 343, 49, 14);
		frame.getContentPane().add(lblNewLabel_5);
		
		JButton btnNewButton_3 = new JButton("Search");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				    Class.forName("com.mysql.cj.jdbc.Driver");
				    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

				    // Use PreparedStatement to safely handle parameters and prevent SQL injection
				    String selectSql = "SELECT * FROM Membership WHERE id = ?";
				    
				    try (PreparedStatement selectPstmt = con.prepareStatement(selectSql)) {
				        // Set the value for the parameter
				        selectPstmt.setString(1, textField_4.getText());

				        // Execute the SELECT query
				        ResultSet resultSet = selectPstmt.executeQuery();

				        // Check if the ID exists
				        if (resultSet.next()) {
				            // ID found, retrieve data from columns
				        	String id=resultSet.getString("id");
				            String name = resultSet.getString("name");
				            String contact = resultSet.getString("contact");
				            String type = resultSet.getString("type");
				            
				            // Do something with the retrieved data (e.g., display or store in variables)
				            textField.setText(id);
		                    textField_1.setText(name);
		                    textField_2.setText(contact);
		                    textField_3.setText(type);
				        } else {
				            // ID not found, handle accordingly (e.g., show an error message)
				        	JOptionPane.showMessageDialog(null, "ID not found.", "Error", JOptionPane.ERROR_MESSAGE);
				            System.out.println("ID not found.");
				            textField.setText("");
		                    textField_1.setText("");
		                    textField_2.setText("");
		                    textField_3.setText("");
				        }
				    }
				} catch (Exception ee) {
				    ee.printStackTrace(); // Handle exceptions properly in a real application
				}

			}
		});
		btnNewButton_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_3.setBounds(92, 373, 173, 23);
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Clear All");
		btnNewButton_4.setBackground(new Color(192, 192, 192));
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
                textField_1.setText("");
                textField_2.setText("");
                textField_3.setText("");
				
			}
		});
		btnNewButton_4.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_4.setBounds(183, 288, 89, 23);
		frame.getContentPane().add(btnNewButton_4);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(331, 80, 323, 334);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnNewButton_5 = new JButton("View Members");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				    Class.forName("com.mysql.cj.jdbc.Driver");
				    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

				    String sql = "SELECT * FROM Membership ORDER BY id ASC";

				    try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
				        ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();
				        DefaultTableModel model = (DefaultTableModel) table.getModel();
				        
				        model.setRowCount(0);

				        int cols = rsmd.getColumnCount();
				        String[] colName = new String[cols];
				        
				        // Populate column names
				        for (int i = 0; i < cols; i++)
				            colName[i] = rsmd.getColumnName(i + 1);
				        
				        model.setColumnIdentifiers(colName);

				        // Populate table data
				        while (rs.next()) {
				            Object[] row = new Object[cols];
				            for (int i = 0; i < cols; i++)
				                row[i] = rs.getObject(i + 1);
				            
				            model.addRow(row);
				        }
				    } // The try-with-resources statement automatically closes the ResultSet, Statement, and Connection

				} catch (Exception ee) {
				    ee.printStackTrace(); // Handle exceptions properly in a real application
				}
				
			}
		});
		btnNewButton_5.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_5.setBounds(92, 407, 173, 23);
		frame.getContentPane().add(btnNewButton_5);
		
		JLabel lblNewLabel_6 = new JLabel("←");	
		lblNewLabel_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				FrontDeskStaff window6 =new FrontDeskStaff();
				window6.frame.setVisible(true);
				frame.dispose();
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 40));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 30));
				
			}
		});
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel_6.setBounds(10, 11, 49, 20);
		frame.getContentPane().add(lblNewLabel_6);
	}
}
