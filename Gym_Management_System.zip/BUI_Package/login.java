package BUI_Package;

import java.awt.EventQueue;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JTextField;

//import DBpackage.Connection;
//import DBpackage.Statememnt;

import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class login {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login window = new login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(197, 74, 96, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(197, 127, 96, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel.setBounds(77, 77, 61, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1.setBounds(77, 130, 61, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("LOGIN FORM");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_2.setBounds(160, 22, 122, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
				    Class.forName("com.mysql.cj.jdbc.Driver");
				    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

				    // Use PreparedStatement to safely handle parameters and prevent SQL injection
				    String sql = "SELECT * FROM frontdesk_login WHERE username = ? AND password = ?";
				    
				    try (PreparedStatement pstmt = con.prepareStatement(sql)) {
				        // Set the values for the parameters
				        pstmt.setString(1, textField.getText());
				        pstmt.setString(2, textField_1.getText());

				        // Execute the query
				        ResultSet resultSet = pstmt.executeQuery();

				      
				        if (resultSet.next()) {
				            // Match found, open the FrontDeskStaff window or perform other actions
				           //FrontDeskStaff FrontDeskStaff= new FrontDeskStaff();
				           //frame.dispose();
				          
				        } else {
				        	textField.setText("");
				        	textField_1.setText("");
				        	
				           //JOptionPane.showMessageDialog(this, "Username or Password is wrong...");
				        }
				    }
				} catch (Exception ee) {
				    ee.printStackTrace(); // Handle exceptions properly in a real application
				}


				
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton.setBounds(160, 181, 89, 23);
		frame.getContentPane().add(btnNewButton);
	}

}
