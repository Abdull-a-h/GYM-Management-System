package BUI_Package;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

import DB__package.DB_CLASS1;

import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Attendance {

	JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTable table;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Attendance window = new Attendance();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Attendance() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 617, 356);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Attendance");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel.setBounds(238, 11, 126, 29);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ID");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_1.setBounds(75, 79, 49, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Date");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_2.setBounds(75, 121, 49, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Status");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_3.setBounds(75, 158, 49, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setBounds(151, 77, 96, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(151, 119, 96, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(151, 156, 96, 20);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(280, 80, 313, 211);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("Mark");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id=textField.getText();
				String date=textField_1.getText();
				String status=textField_2.getText();
				
				
				DB_CLASS1.getinstance().viewmessage();
				DB_CLASS1.getinstance().mark(id,date,status);

			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton.setBounds(75, 197, 81, 29);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_4 = new JLabel("ID");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_4.setBounds(44, 239, 49, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		textField_3 = new JTextField();
		textField_3.setBounds(116, 237, 96, 20);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("View Attendance");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				    Class.forName("com.mysql.cj.jdbc.Driver");
				    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda", "root", "958boult&*");

				    // Check if the class exists in the Fitness_Class table
				    String classCheckSql = "SELECT * FROM attendance WHERE id = ?";

				    try (PreparedStatement classCheckPstmt = con.prepareStatement(classCheckSql)) {
				        // Set the value for the parameter
				        classCheckPstmt.setString(1, textField_3.getText());

				        // Execute the SELECT query
				        ResultSet classCheckResultSet = classCheckPstmt.executeQuery();

				        // Check if the class exists
				        if (!classCheckResultSet.next()) {
				            // Member doesn't exist, handle accordingly (e.g., show an error message)
				        	JOptionPane.showMessageDialog(null, "Member with ID " + textField_3.getText() + " doesn't exist. Display failed.", "Error", JOptionPane.ERROR_MESSAGE);
				          
				            return; // Exit the method, as there's no point in proceeding further
				        }
				    }

				    // Fetch and display the member IDs for the provided class ID
				    String sql = "SELECT Date, status FROM attendance WHERE id = ? Order by Date asc";

				    try (PreparedStatement pstmt = con.prepareStatement(sql)) {
				        // Set the value for the parameter
				        pstmt.setString(1, textField_3.getText());

				        // Execute the SELECT query
				        ResultSet rs = pstmt.executeQuery();

				        // Display only the member column in the table
				        ResultSetMetaData rsmd = (ResultSetMetaData) rs.getMetaData();
				        DefaultTableModel model = (DefaultTableModel) table.getModel();

				        model.setRowCount(0);

				        int cols = rsmd.getColumnCount();
				        String[] colName = new String[cols];

				        // Populate column names
				        for (int i = 0; i < cols; i++)
				            colName[i] = rsmd.getColumnName(i + 1);

				        model.setColumnIdentifiers(colName);

				        // Populate table data
				        while (rs.next()) {
				            Object[] row = new Object[cols];
				            for (int i = 0; i < cols; i++)
				                row[i] = rs.getObject(i + 1);

				            model.addRow(row);
				        }
				    }
				} catch (Exception ee) {
				    ee.printStackTrace(); // Handle exceptions properly in a real application
				}
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_1.setBounds(54, 264, 137, 26);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Update");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id=textField.getText();
				String date=textField_1.getText();
				String status=textField_2.getText();
				
				
				DB_CLASS1.getinstance().viewmessage();
				DB_CLASS1.getinstance().updatee(id,date,status);

			}
		});
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton_2.setBounds(176, 198, 81, 29);
		frame.getContentPane().add(btnNewButton_2);
		
		JLabel lblNewLabel_5 = new JLabel("←");
		lblNewLabel_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				FrontDeskStaff window6 =new FrontDeskStaff();
				window6.frame.setVisible(true);
				frame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 40));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 30));
			}
		});
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel_5.setBounds(10, 11, 49, 20);
		frame.getContentPane().add(lblNewLabel_5);
	}

}
